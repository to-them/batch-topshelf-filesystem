﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n File System......");
            getDirectory();
            Console.WriteLine("");
            Console.Write("\n PRESS ANY KEY QUIT: ");
            Console.ReadKey();
        }

        //Ref: https://stackoverflow.com/questions/816566/how-do-you-get-the-current-project-directory-from-c-sharp-code-when-creating-a-c
        static void getDirectory()
        {            
            var parent = Directory.GetParent(Directory.GetCurrentDirectory()).Parent;
            string startDirectory = null;
            if (parent != null)
            {
                var directoryInfo = parent.Parent;
                
                if (directoryInfo != null)
                {
                    startDirectory = directoryInfo.FullName;
                }
                if (startDirectory != null)
                { /*Do whatever you want "startDirectory" variable*/}
            }

            //Also take note when you change Any CPU to a specified platform

            //To the Solution Folder
            Console.WriteLine("Solution: {0}", startDirectory);

            //To a Project Folder in the Solution
            string s = Path.GetFullPath(@"..\..\");
            Console.WriteLine("Project1: {0}", s);

            string projectDir = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\.."));
            Console.WriteLine("Project2: {0}", s);

            //To the current configuration/working Directory (ex: \bin\Debug, \bin\Cert, \bin\Prod)          
            string workingDirectory = AppDomain.CurrentDomain.BaseDirectory;
            Console.WriteLine("Working Dir: {0}", workingDirectory);

            //This will get the current PROJECT bin directory (ie ../bin/)
            string binDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            Console.WriteLine("Bin Dir: {0}", binDirectory);

            /*
            // This will get the current WORKING directory (i.e. \bin\Debug)
            string workingDirectory = Environment.CurrentDirectory;
            // or: Directory.GetCurrentDirectory() gives the same result

            // This will get the current PROJECT bin directory (ie ../bin/)
            string projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;

            // This will get the current PROJECT directory
            string projectDirectory = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
            */

        }
    }
}
