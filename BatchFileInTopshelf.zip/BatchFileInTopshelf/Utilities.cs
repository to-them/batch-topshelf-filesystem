﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchFileInTopshelf
{
    public class Utilities
    {
        #region File Configurations
        public static string getFilePath = ConfigurationManager.AppSettings["BatchFilePath"].ToString();
        public static string getArgumentName = ConfigurationManager.AppSettings["ArgumentName"].ToString();
        public static string getServiceDataFilePath = ConfigurationManager.AppSettings["ServiceDataFilePath"].ToString();

        private static string getFileName = ConfigurationManager.AppSettings["BatchFileName"].ToString();
        public static string getFullPath
        {
            get
            {
                return Path.GetFullPath(@"..\..\" + getFileName);
            }
        }

        private static string ServiceDataFileName = ConfigurationManager.AppSettings["ServiceDataFileName"].ToString();
        public static string getServiceDataFile
        {
            get
            {
                return Path.GetFullPath(@"..\..\" + ServiceDataFileName);
            }
        }
        #endregion

        #region Email Configurations
        public static string getSenderEmail = ConfigurationManager.AppSettings["SenderEmail"].ToString();
        public static string getSenderName = ConfigurationManager.AppSettings["SenderName"].ToString();
        public static string getSenderPhone = ConfigurationManager.AppSettings["SenderPhone"].ToString();
        public static string getRecipientEmail = ConfigurationManager.AppSettings["RecipientEmail"].ToString();
        public static string getRecipientName = ConfigurationManager.AppSettings["RecipientName"].ToString();        
        #endregion
    }
}
