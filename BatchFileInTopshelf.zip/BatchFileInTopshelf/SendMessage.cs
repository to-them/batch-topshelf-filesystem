﻿using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchFileInTopshelf
{
    public class SendMessage
    {
        private string _SendGridKey = ConfigurationManager.AppSettings["SendGridKey"].ToString();

        public string SendEmail(string subject, string message)
        {
            string msg = "";
            try
            {
                Email em = new Email()
                {
                    sender_email = Utilities.getSenderEmail,
                    sender_name = Utilities.getSenderName,
                    sender_phone = Utilities.getSenderPhone,
                    sender_message = message,
                    email_subject = subject,
                    recipient_email = Utilities.getRecipientEmail,
                    recipient_name = Utilities.getRecipientName
                };

                SendGridEmail(em).Wait();

                msg = " >>Email sent!";
            }
            catch (Exception ex)
            {
                msg = " Error: " + ex.InnerException.ToString();
            }

            return msg;
        }

        private async Task SendGridEmail(Email em)
        {
            var client = new SendGridClient(_SendGridKey);
            var from = new EmailAddress(em.sender_email, em.sender_name);
            var subject = em.email_subject;
            var to = new EmailAddress(em.recipient_email, em.recipient_name);
            var plainTextContent = em.sender_phone + "\n" + em.sender_message;
            var htmlContent = "<div>" + em.sender_phone + "</div><p>" + em.sender_message + "</p>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
        }

        private async Task SendGridEmail(
            string sender_email, string sender_name,
            string sender_phone, string sender_message,
            string email_subject, string recipient_email, string recipient_name)
        {
            var client = new SendGridClient(_SendGridKey);
            var from = new EmailAddress(sender_email, sender_name);
            var subject = email_subject;
            var to = new EmailAddress(recipient_email, recipient_name);
            var plainTextContent = sender_phone + "\n" + sender_message;
            var htmlContent = "<div>" + sender_phone + "</div><p>" + sender_message + "</p>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
        }
    }
}
