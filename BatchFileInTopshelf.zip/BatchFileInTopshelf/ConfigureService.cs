﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf;

namespace BatchFileInTopshelf
{
    internal static class ConfigureService
    {
        internal static void Configure()
        {
            var exitCode = HostFactory.Run(x =>
            {
                x.Service<Service>(s =>
                {
                    s.ConstructUsing(winservice => new Service());
                    s.WhenStarted(winservice => winservice.Start());
                    s.WhenStopped(winservice => winservice.Stop());
                });

                //Set account that windows service to run at
                x.RunAsLocalSystem();

                x.SetServiceName("WinService");
                x.SetDisplayName("Sample Windows Service");
                x.SetDescription("This is a sample Windows service demo.");
            });

            int exitCodeValue = (int)Convert.ChangeType(exitCode, exitCode.GetTypeCode());
            Environment.ExitCode = exitCodeValue;
        }
    }
}
