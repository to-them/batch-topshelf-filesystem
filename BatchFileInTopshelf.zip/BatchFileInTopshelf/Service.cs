﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace BatchFileInTopshelf
{
    public class Service
    {
        private readonly Timer _timer;

        public Service()
        {
            _timer = new Timer(60000) { AutoReset = true };
            _timer.Elapsed += TimerElapsed;
        }

        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            //For continuous run at setting intervals
            DoSomething();
        }

        public void Start()
        {
            Console.WriteLine("Service started....");
            // write code here that runs when the Windows Service starts up. 

            //Run continuosuly at timer intervals
            _timer.Start();

            //Just run on demand
            //DoSomething();
        }

        public void Stop()
        {
            // write code here that runs when the Windows Service stops.
            _timer.Stop();
            Console.WriteLine("Service stopped!");
        }

        private void DoSomething()
        {
            #region Write to text file
            // write code here that runs when the time elapsed
            Console.WriteLine("\n >>Write to text file...");
            string message = DateTime.Now.ToString() + ": A message from the Service...";

            //Write to file
            string[] lines = new string[] { message };

            //File in remote location - ideal for continuous or on demand operation
            File.AppendAllLines(Utilities.getServiceDataFilePath, lines);

            //File in root directory of project - ideal for on demand operation
            //File.AppendAllLines(Utilities.getServiceDataFile, lines); 
            Console.WriteLine(" File write complete!");
            #endregion

            #region Batch file job
            //Batch file job
            Console.WriteLine(" >>Run Batch File Job...");
            string msg = string.Empty;
            try
            {
                Process.Start(Utilities.getFullPath, Utilities.getArgumentName);
                msg = " Batch job complete!";
            }
            catch (System.Exception ex)
            {
                msg = " >>Exception: " + ex.InnerException.Message;
                throw ex;
            }
            Console.WriteLine(msg);
            #endregion

            #region Email Notification
            //Send Notification
            SendMessage send = new SendMessage();
            message += "\n" + msg;
            string emsg = send.SendEmail("-=-=- Test Winservice TopShelf -=-=-", message);
            Console.WriteLine(emsg);
            #endregion

        }
    }
}
