﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchFileInConsoleApp
{
    public class Utilities
    {
        public static string getFilePath = ConfigurationManager.AppSettings["FilePath"].ToString();       
        public static string getArgumentName = ConfigurationManager.AppSettings["ArgumentName"].ToString();
        private static string getFileName = ConfigurationManager.AppSettings["FileName"].ToString();

        public static string getFullPath
        {
            get
            {
                return Path.GetFullPath(@"..\..\"+ getFileName);
            }
        }
    }
}
