﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchFileInConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {            
            Console.WriteLine(" Run Batch File Job...");
            string msg = string.Empty;
            try
            {
                Process.Start(Utilities.getFullPath, Utilities.getArgumentName);
                msg = " Job complete!";
            }
            catch(System.Exception ex)
            {
                msg = "Exception: " + ex.InnerException.Message;
                throw ex;
            }
            Console.WriteLine(msg);
            Console.Write("\n PRESS ANY KEY TO EXIT: ");
            Console.ReadKey();
        }
    }
}
